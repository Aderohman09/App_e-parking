-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Feb 2024 pada 05.06
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_parkir`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `harga`
--

CREATE TABLE `harga` (
  `Kode` int(10) NOT NULL,
  `Motor` varchar(30) NOT NULL,
  `Mobil` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `harga`
--

INSERT INTO `harga` (`Kode`, `Motor`, `Mobil`) VALUES
(1, '', '2000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_akses_admin`
--

CREATE TABLE `tb_akses_admin` (
  `username` varchar(50) NOT NULL,
  `jam_login` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_akses_admin`
--

INSERT INTO `tb_akses_admin` (`username`, `jam_login`) VALUES
('alex', '20:03'),
('alex', '14:11'),
('admin', '07:52'),
('ade rohman', '07:53'),
('ade rohman', '07:53'),
('ade rohman', '08:02'),
('ade rohman', '08:02'),
('ade rohman', '08:08'),
('ade rohman', '08:15'),
('ade rohman', '08:34'),
('ade rohman', '08:34'),
('ade rohman', '08:34'),
('ade rohman', '08:36'),
('ade rohman', '09:58'),
('ade rohman', '10:04'),
('ade rohman', '10:10'),
('ade rohman', '10:14'),
('ade rohman', '13:53'),
('ade rohman', '14:01'),
('ade rohman', '08:48'),
('ade rohman', '09:41'),
('ade rohman', '09:41'),
('ade rohman', '09:48'),
('ade rohman', '10:01'),
('ade rohman', '10:01'),
('ade rohman', '10:02'),
('ade rohman', '10:53'),
('ade rohman', '08:25'),
('ade rohman', '08:54'),
('ade rohman', '09:42'),
('ade rohman', '09:42'),
('ade rohman', '09:42'),
('ade rohman', '09:43'),
('ade rohman', '09:59'),
('ade rohman', '07:27'),
('ade rohman', '07:36'),
('ade rohman', '09:27'),
('ade rohman', '10:04'),
('ade rohman', '13:31'),
('ade rohman', '14:22'),
('ade rohman', '11:26'),
('ade rohman', '08:07'),
('ade rohman', '09:49'),
('ade rohman', '09:52'),
('ade rohman', '09:55'),
('ade rohman', '10:40'),
('ade rohman', '10:54'),
('ade rohman', '10:56'),
('ade rohman', '11:12'),
('ade rohman', '11:22'),
('ade rohman', '11:30'),
('ade rohman', '11:31'),
('ade rohman', '08:08'),
('ade rohman', '10:12'),
('ade rohman', '10:17'),
('ade rohman', '10:39'),
('ade rohman', '10:47'),
('ade rohman', '11:14'),
('ade rohman', '13:08'),
('ade rohman', '07:49'),
('ade rohman', '09:11'),
('ade rohman', '09:11'),
('ade rohman', '09:39'),
('ade rohman', '09:45'),
('ade rohman', '10:57');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_daftar_parkir`
--

CREATE TABLE `tb_daftar_parkir` (
  `kode` varchar(5) NOT NULL,
  `plat_nomor` varchar(10) NOT NULL,
  `jenis` varchar(22) NOT NULL,
  `merk` varchar(30) NOT NULL,
  `hitung_jam_masuk` int(11) NOT NULL,
  `jam_masuk` varchar(9) NOT NULL,
  `status` varchar(2) NOT NULL,
  `jam_keluar` varchar(9) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_daftar_parkir`
--

INSERT INTO `tb_daftar_parkir` (`kode`, `plat_nomor`, `jenis`, `merk`, `hitung_jam_masuk`, `jam_masuk`, `status`, `jam_keluar`, `harga`) VALUES
('EP990', 'Dokujhjh', 'Truk/Bus/Lainnya', 'suzuki', 14, '14:13', '1', '', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_login`
--

CREATE TABLE `tb_login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `tb_login`
--

INSERT INTO `tb_login` (`username`, `password`) VALUES
('ade rohman', '1111');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `harga`
--
ALTER TABLE `harga`
  ADD PRIMARY KEY (`Kode`);

--
-- Indeks untuk tabel `tb_daftar_parkir`
--
ALTER TABLE `tb_daftar_parkir`
  ADD PRIMARY KEY (`kode`);

--
-- Indeks untuk tabel `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `harga`
--
ALTER TABLE `harga`
  MODIFY `Kode` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
