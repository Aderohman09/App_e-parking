<?php
// Mengambil data dari form
$kode = $_POST['kode'];
$plat_nomor = $_POST['plat_nomor'];
$jenis = $_POST['jenis'];
$merk = $_POST['merk'];
$jam_masuk = $_POST['jam_masuk'];
$jam_keluar = '14:29'; // Jam keluar tetap 14:29
$harga = 2000; // Harga tetap 2000

// Proses pembayaran
// Misalnya, di sini Anda dapat menyimpan data pembayaran ke database atau melakukan proses pembayaran lainnya

// Menampilkan struk keluar parkir
echo "<h2>Struk Keluar Parkir</h2>";
echo "<p>Kode: $kode</p>";
echo "<p>Plat Nomor: $plat_nomor</p>";
echo "<p>Jenis: $jenis</p>";
echo "<p>Merk: $merk</p>";
echo "<p>Jam Masuk: $jam_masuk</p>";
echo "<p>Jam Keluar: $jam_keluar</p>";
echo "<p>Harga: $harga</p>";
?>
